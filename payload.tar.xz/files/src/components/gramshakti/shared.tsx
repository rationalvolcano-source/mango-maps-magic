import { createContext, useContext, useState, type ReactNode } from "react";
import { Link, useNavigate, useSearch } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowUpRight,
  BookOpen,
  ChevronRight,
  Leaf,
  Search,
  SlidersHorizontal,
  Sprout,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { months, evidence, type Evidence } from "@/lib/gramshakti/data";
import logo from "@/assets/gramshakti/logo.png.asset.json";
const SourceContext = createContext<(record: Evidence) => void>(() => {});
export const useSource = () => useContext(SourceContext);
export function EvidenceProvider({ children }: { children: ReactNode }) {
  const [record, setRecord] = useState<Evidence>();
  return (
    <SourceContext.Provider value={setRecord}>
      {children}
      <Sheet
        open={!!record}
        onOpenChange={(open) => {
          if (!open) setRecord(undefined);
        }}
      >
        <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
          <SheetHeader>
            <span className="eyebrow mb-4">EVIDENCE RECORD</span>
            <SheetTitle className="pr-7 text-2xl">{record?.title}</SheetTitle>
            <SheetDescription>Source provenance and interpretation</SheetDescription>
          </SheetHeader>
          {record && (
            <div className="mt-8 space-y-6">
              {[
                ["Exact passage / tab / row", record.passage],
                ["Reporting period", record.period],
                ["Native unit", record.nativeUnit],
                ["Display unit", record.displayUnit],
                ["Evidence class", record.evidenceClass],
                ["Transformation", record.transformation],
              ].map(([label, value]) => (
                <div key={label}>
                  <h3 className="mb-1 text-xs font-semibold uppercase text-muted-foreground">
                    {label}
                  </h3>
                  <p className="source-passage text-sm leading-relaxed">{value}</p>
                </div>
              ))}
              <div className="notice">
                <h3 className="font-semibold">Caveat</h3>
                <p className="mt-2 text-sm">{record.caveat}</p>
              </div>
              {record.url ? (
                <Button asChild>
                  <a href={record.url} target="_blank" rel="noreferrer">
                    Open source <ArrowUpRight />
                  </a>
                </Button>
              ) : (
                <p className="text-sm text-muted-foreground">Source link not supplied.</p>
              )}
              {record.upstreamUrl && (
                <Button asChild variant="outline">
                  <a href={record.upstreamUrl} target="_blank" rel="noreferrer">
                    Upstream publication <ArrowUpRight />
                  </a>
                </Button>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>
    </SourceContext.Provider>
  );
}
export function Brand() {
  return (
    <Link to="/" search={(p) => p} className="brand" aria-label="GramShakti home">
      <img className="h-10 w-auto" src={logo.url} alt="GramShakti" />
    </Link>
  );
}
export function EntryScene({ children }: { children: ReactNode }) {
  return <div>{children}</div>;
}
export function SourceButton({
  record,
  label = "Source",
  iconOnly = false,
}: {
  record: Evidence;
  label?: string;
  iconOnly?: boolean;
}) {
  const source = useSource();
  return (
    <Button
      variant="ghost"
      size={iconOnly ? "icon" : "sm"}
      onClick={() => source(record)}
      aria-label={iconOnly ? `Source for ${record.title}` : undefined}
      title={`Evidence: ${record.title}`}
      className="text-muted-foreground"
    >
      <BookOpen />
      {!iconOnly && label}
    </Button>
  );
}
export function AppHeader() {
  return (
    <header className="app-header">
      <div className="app-header-inner">
        <Brand />
        <div className="flex shrink-0 items-center gap-2">
          <span className="hidden text-xs text-muted-foreground sm:block">
            INDIA AGRICULTURE INTELLIGENCE
          </span>
          <Button asChild variant="outline" size="sm">
            <Link to="/choose" search={(p) => p}>
              Change objective <ArrowUpRight />
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
export function SelectionControls() {
  const selection = useSearch({ strict: false });
  const navigate = useNavigate();
  return (
    <div className="selection-controls">
      <div className="segmented" aria-label="Procurement purpose">
        {["fresh", "processed"].map((p) => (
          <Button
            key={p}
            variant={selection.purpose === p ? "default" : "ghost"}
            size="sm"
            onClick={() =>
              navigate({
                to: ".",
                search: (prev) => ({ ...prev, purpose: p === "processed" ? "processed" : "fresh" }),
              })
            }
          >
            {p === "fresh" ? "Fresh" : "Processed"}
          </Button>
        ))}
      </div>
      <label className="month-control">
        <SlidersHorizontal className="size-4 text-muted-foreground" />
        <span>Target month</span>
        <select
          aria-label="Target month"
          value={selection.month ?? ""}
          onChange={(e) =>
            navigate({
              to: ".",
              search: (prev) => ({ ...prev, month: e.target.value || undefined }),
            })
          }
        >
          <option value="">Any month</option>
          {months.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </select>
      </label>
    </div>
  );
}
export function PageShell({
  title,
  subtitle,
  children,
  back = true,
  eyebrow = "MANGO PROCUREMENT",
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  back?: boolean;
  eyebrow?: string;
}) {
  return (
    <>
      <AppHeader />
      <main className="page-container">
        <nav className="breadcrumbs">
          <Link to="/choose" search={(p) => p}>
            Objectives
          </Link>
          <ChevronRight />
          <Link to="/procurement" search={(p) => p}>
            Procurement
          </Link>
          <ChevronRight />
          <span>Mango</span>
        </nav>
        {back && (
          <Button asChild variant="link" className="mb-3 h-auto p-0">
            <Link to="/procurement/mango" search={(p) => p}>
              <ArrowLeft /> Back to sourcing landscape
            </Link>
          </Button>
        )}
        <div className="page-heading">
          <div className="min-w-0">
            <span className="eyebrow">{eyebrow}</span>
            <h1>{title}</h1>
            {subtitle && <p className="mt-2 text-muted-foreground">{subtitle}</p>}
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span className="period-chip">2024–25</span>
            <SourceButton record={evidence(`${title} — source register`)} label="Sources" />
          </div>
        </div>
        {children}
        <footer className="application-footer">
          <Brand />
          <span>Evidence-led. Geography-aware. Agriculture-first.</span>
        </footer>
      </main>
    </>
  );
}
export function SectionTitle({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: typeof Leaf;
  title: string;
  subtitle?: string;
  children?: ReactNode;
}) {
  return (
    <div className="section-title">
      <div className="flex min-w-0 items-start gap-3">
        <Icon className="mt-0.5 size-5 shrink-0 text-leaf" />
        <div className="min-w-0">
          <h2>{title}</h2>
          {subtitle && <p>{subtitle}</p>}
        </div>
      </div>
      {children}
    </div>
  );
}
export function MissingEvidence({ children }: { children?: ReactNode }) {
  return (
    <div className="missing-evidence">
      <BookOpen className="size-5 text-muted-foreground" />
      <span>{children ?? "Verified records are not yet available."}</span>
    </div>
  );
}
export function SearchInput({
  value,
  onChange,
  placeholder = "Search crops…",
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="search-input">
      <Search className="size-5 shrink-0 text-muted-foreground" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label={placeholder}
      />
      {value && (
        <Button size="sm" variant="ghost" onClick={() => onChange("")}>
          Clear
        </Button>
      )}
    </label>
  );
}
