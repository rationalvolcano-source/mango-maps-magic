import { useState } from "react";
import { Bug, Shield, MapPin, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { states, targets, evidence } from "@/lib/gramshakti/data";
import { PageShell, SourceButton } from "./shared";
export function ProtectionPage() {
  const [type, setType] = useState("All");
  const [zone, setZone] = useState("All");
  const [state, setState] = useState("All");
  const shown = targets.filter(
    (t) =>
      (type === "All" || t.type === type) &&
      (zone === "All" || t.zone === zone) &&
      (state === "All" || t.state === state),
  );
  return (
    <PageShell
      title="Mango • regional pest and management context"
      subtitle="Crop-stage relevance and management categories, with evidence boundaries."
    >
      <div className="protection-toolbar">
        <div className="segmented">
          {["All", "Pests", "Diseases"].map((t) => (
            <Button
              key={t}
              variant={type === t ? "default" : "ghost"}
              size="sm"
              onClick={() => setType(t)}
            >
              {t}
            </Button>
          ))}
        </div>
        <div className="flex flex-wrap gap-3">
          <label className="filter-control">
            Zone
            <select
              aria-label="Protection zone"
              value={zone}
              onChange={(e) => setZone(e.target.value)}
            >
              {["All", "North", "South", "West", "East", "Central", "Northeast"].map((z) => (
                <option key={z} value={z}>
                  {z === "All" ? "All zones" : z}
                </option>
              ))}
            </select>
          </label>
          <label className="filter-control">
            State
            <select
              aria-label="Protection state"
              value={state}
              onChange={(e) => setState(e.target.value)}
            >
              <option value="All">All states</option>
              {states.map((s) => (
                <option key={s.code} value={s.code}>
                  {s.name}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>
      <div className="notice slim">
        <Shield className="size-5 shrink-0" />
        <span>
          Target descriptions and regional tags are provisional. No management category is verified
          without its source record.
        </span>
      </div>
      <p className="mb-5 text-xs text-muted-foreground">
        {shown.length} targets · Source validation pending
      </p>
      <div className="protection-grid">
        {shown.map((t) => (
          <section className={`content-card target-card zone-${t.zone.toLowerCase()}`} key={t.id}>
            <div className="flex items-center justify-between">
              <span className="target-type">
                <Bug className="size-4" />
                {t.type === "Pests" ? "PEST" : "DISEASE"}
              </span>
              <SourceButton
                iconOnly
                record={evidence(`${t.name} — management context`, t.scientific, {
                  period: "Source reporting period not supplied",
                  caveat:
                    "Scientific names and general descriptions are provisional. Regional relevance, timing and management modes require source validation. Not a pesticide prescription.",
                })}
              />
            </div>
            <h2>{t.name}</h2>
            <p className="scientific-name">{t.scientific}</p>
            <span className="target-geography">
              <MapPin />
              {t.zone} India · Provisional regional context
            </span>
            <h3>COMMERCIAL IMPACT</h3>
            <p>{t.impact}</p>
            <div className="target-timing">
              <CalendarDays />
              <p>{t.timing}</p>
            </div>
            <h3>MANAGEMENT CONTEXT — UNVERIFIED</h3>
            <div className="flex flex-wrap gap-2">
              {t.categories.map((c) => (
                <span className="management-chip" key={c}>
                  {c}
                </span>
              ))}
            </div>
            <p className="footnote">
              Biological context: no validated record supplied. No doses, spray schedules or PHIs
              displayed.
            </p>
          </section>
        ))}
      </div>
      {shown.length === 0 && (
        <div className="missing-evidence py-12">
          No targets match these filters. Regional evidence remains incomplete.
        </div>
      )}
      <div className="protection-disclaimer">
        <Shield />
        <p>
          Source-based crop protection context; not an outbreak forecast or pesticide prescription.
        </p>
      </div>
    </PageShell>
  );
}
