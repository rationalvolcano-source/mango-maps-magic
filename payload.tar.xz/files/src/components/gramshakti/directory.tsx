import { useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Apple,
  Bean,
  Carrot,
  Flower2,
  Leaf,
  Sprout,
  TreePine,
  Wheat,
  ArrowUpRight,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { categories, blocked } from "@/lib/gramshakti/data";
import { AppHeader, SearchInput, SelectionControls } from "./shared";
const icons = [Wheat, Bean, Sprout, Flower2, Apple, Carrot, TreePine, Leaf];
export function DirectoryPage() {
  const [search, setSearch] = useState("");
  const [crop, setCrop] = useState<string>();
  const count = categories
    .flatMap((c) => c.crops)
    .filter((c) => c.toLowerCase().includes(search.toLowerCase())).length;
  return (
    <>
      <AppHeader />
      <main className="page-container directory">
        <nav className="breadcrumbs">
          <Link to="/choose" search={(p) => p}>
            Objectives
          </Link>
          <span>/</span>
          <span>Procurement</span>
        </nav>
        <span className="eyebrow">FROM INTENT TO INTELLIGENCE</span>
        <h1>What do you want to procure?</h1>
        <p className="mt-3 text-muted-foreground">
          Start with a crop. Discover the geography behind it.
        </p>
        <div className="directory-toolbar">
          <SearchInput value={search} onChange={setSearch} />
          <SelectionControls />
        </div>
        <div className="directory-caption">
          <span>
            <strong>{count}</strong> crops · 8 categories
          </span>
          <span>Mango sourcing journey available</span>
        </div>
        <div className="category-grid">
          {categories.map((category, i) => {
            const crops = category.crops.filter((c) =>
              c.toLowerCase().includes(search.toLowerCase()),
            );
            const Icon = icons[i] ?? Leaf;
            return crops.length > 0 ? (
              <section className="category-card" key={category.name}>
                <div className="flex items-center gap-3">
                  <span className="category-icon">
                    <Icon />
                  </span>
                  <h2>{category.name}</h2>
                  <span className="ml-auto text-xs text-muted-foreground">{crops.length}</span>
                </div>
                <div className="crop-grid">
                  {crops.map((c) =>
                    c === "Mango" ? (
                      <Button asChild key={c} variant="outline" className="mango-crop">
                        <Link to="/procurement/mango" search={(p) => p}>
                          <Apple />
                          Mango
                          <ArrowUpRight />
                        </Link>
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        key={c}
                        onClick={() => setCrop(c)}
                        className="crop-button"
                      >
                        {c}
                      </Button>
                    ),
                  )}
                </div>
              </section>
            ) : null;
          })}
        </div>
        {count === 0 && (
          <p className="py-20 text-center text-muted-foreground">No crops match “{search}”.</p>
        )}
        <div className="directory-note">
          <Leaf />
          <span>Every sourcing decision starts with a better understanding of place.</span>
        </div>
      </main>
      <Sheet
        open={!!crop}
        onOpenChange={(open) => {
          if (!open) setCrop(undefined);
        }}
      >
        <SheetContent>
          <SheetHeader>
            <AlertTriangle className="mb-4 size-8 text-saffron" />
            <SheetTitle>
              {crop && blocked.includes(crop) ? "Source repair required" : "Not yet implemented"}
            </SheetTitle>
            <SheetDescription>{crop}</SheetDescription>
          </SheetHeader>
          <p className="mt-6 leading-relaxed">
            {crop && blocked.includes(crop)
              ? "This crop is blocked pending source repair. The correction register containing its specific reason has not been supplied; no reason has been inferred."
              : "This crop’s procurement journey is not yet available. Explore Mango for the current sourcing experience."}
          </p>
          <Button className="mt-6" onClick={() => setCrop(undefined)}>
            Return to crop directory
          </Button>
        </SheetContent>
      </Sheet>
    </>
  );
}
